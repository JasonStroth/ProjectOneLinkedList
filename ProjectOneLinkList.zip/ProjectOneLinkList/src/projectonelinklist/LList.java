package projectonelinklist;

import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author jason stroth
 */
public class LList
{
    private Link root = null; 
    int max = 5; // limit for link list.
    
    
    //These functions add a value to the linked list
    
    public void AddToList(int value)  
    {
        if (root == null)
        {
            root = new Link();
            root.info = value;
        }
        else
        {
            add(value);
        }
    }
    
    private void add(int value)
    {
        recAdd(value, root);
    }
    
    private void recAdd(int value, Link myLink)
    {
        if (myLink.nextLink == null)
        {
            Link temp = new Link();
            temp.info = value;
            myLink.nextLink = temp;
        }
        else
        {
            recAdd(value, myLink.nextLink);
        }
    }    
    // Functions print out list
    public void printOut()
    {
        recPrintOut(root);        
    }
    private void recPrintOut(Link list)
    {
        // this will stop the list when null
        if(list != null)
        {
            System.out.print("\t"+list.info);
            recPrintOut(list.nextLink);
        }
    }
// To remove integer from stack. Compare user's input to LList using a loop
    public void popStack(int value)
    {
        int i;
        for(i = 0; i < max; i++)
        {
            if (AddToList(i) == value)
            {
                delete(value, Link remove);
            }
            else
            {
                System.out.println(" \t This number does not match the link list. ");
            }
        }
    }
    
 // Could not figure out how to remove link and move to next node.
    public int delete(int value, Link remove)
    {
        if (int value < max)
        {
            remove.info;
            return 
        }
    }
    
    
    void AddToList() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
