/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projectonelinklist;
import java.util.Scanner;
/**
 *
 *                          @author Jeffrey Jason Stroth
 *                             Project One: Linked List   
 * 
 */
public class ProjectOneLinkList {

    public static void main(String[] args) 
    {
        LList myList = new LList();        
        Scanner s = new Scanner (System.in);
       
    // For simplification, User input has been limited to input 5 integers
    int max = 5;
       for(int i = 0; i < max; i++)
       {
       System.out.println(" \t Please enter an integer for the stack:\n ");
       myList.AddToList(s.nextInt());
       }
    
//Display information
       myList.printOut();
       
// Ask user which number to pop off stack:
System.out.println(" \t Which number would you like to pop off the stack?: ");
    myList.popStack(s.nextInt());
    
//Display information again
       myList.printOut();    
    }         
}